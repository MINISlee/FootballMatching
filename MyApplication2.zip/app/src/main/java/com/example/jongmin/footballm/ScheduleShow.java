package com.example.jongmin.footballm;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ScheduleShow extends AppCompatActivity {


    private ListView matchListView;
    private MatchListAdapter matchAdapter;
    private List<Match> matchList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_show);

        matchListView = (ListView) findViewById(R.id.matchListView);
        matchList = new ArrayList<Match>();
        matchAdapter = new MatchListAdapter(getApplicationContext(), matchList);
        matchListView.setAdapter(matchAdapter);

        String[] str = getResources().getStringArray(R.array.areaArray);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, str);
        Spinner spi = (Spinner)findViewById(R.id.areaSpinner);
        spi.setAdapter(adapter);
        spi.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected
                            (AdapterView<?> parent, View view, int position, long id){
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent){

                    }
                }
        );
        new BackgroundTask().execute();
    }




    class BackgroundTask extends AsyncTask<Void, Void, String> {

        String target;

        @Override
        protected void onPreExecute() {
            target = "http://jjong921217.cafe24.com/FootballList.php";
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL(target);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferReader = new BufferedReader(new InputStreamReader(inputStream));
                String temp;
                StringBuilder stringBuilder = new StringBuilder();
                while ((temp = bufferReader.readLine()) != null) {
                    stringBuilder.append(temp + "\n");
                }
                bufferReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return stringBuilder.toString().trim();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate();
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonArray = jsonObject.getJSONArray("response");



                Log.v("리스폰스", String.valueOf(jsonArray));
                int count = 0;


                String teamName, area;
                String kakaoID,phone;
                String yearDATE,  monthDATE, dayDATE;
                String sunTIME,hourTIME, minTIME;

                while (count < jsonArray.length()) {
                    JSONObject object = jsonArray.getJSONObject(count);
                    teamName = object.getString("teamName");
                    area = object.getString("area");
                    kakaoID = object.getString("kakaoID");
                    phone = object.getString("phone");
                    yearDATE = String.valueOf(object.getInt("yearDATE"));
                    monthDATE = String.valueOf(object.getInt("monthDATE"));
                    dayDATE = String.valueOf(object.getInt("dayDATE"));

                    sunTIME = object.getString("sunTIME");
                    hourTIME = String.valueOf(object.getInt("hourTIME"));
                    minTIME = String.valueOf(object.getInt("minTIME"));





                    Log.d("카카오아이디",kakaoID);
                    Log.d("전화번호",phone);
                    Log.d("팀이름",teamName);
                    Log.d("지역",area);
                    Log.d("연도", String.valueOf(yearDATE));
                    Log.d("월", String.valueOf(monthDATE));
                    Log.d("일", String.valueOf(dayDATE));
                    Log.d("AMPM",sunTIME);
                    Log.d("시", String.valueOf(hourTIME));
                    Log.d("분", String.valueOf(minTIME));


                    Match match = new Match(teamName, area, yearDATE, monthDATE, dayDATE, sunTIME, hourTIME, minTIME);

                    matchList.add(match);
                    count++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
