package com.example.jongmin.footballm;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Jongmin on 2017-07-07.
 */

public class MatchListAdapter extends BaseAdapter {

    private Context  context;
    private List<Match> matchList;

    public MatchListAdapter(Context context, List<Match> matchList) {
        this.context = context;
        this.matchList = matchList;
    }

    @Override
    public int getCount() {
        return matchList.size();
    }

    @Override
    public Object getItem(int position) {
        return matchList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(context, R.layout.match, null);
        TextView yearDateText = (TextView)v.findViewById(R.id.yearDateText);
        TextView monthDateText = (TextView)v.findViewById(R.id.monthDateText);
        TextView dayDateText = (TextView)v.findViewById(R.id.dayDateText);

        TextView sunTimeText = (TextView)v.findViewById(R.id.sunTimeText);
        TextView hourTimeText = (TextView)v.findViewById(R.id.hourTimeText);
        TextView minTimeText = (TextView)v.findViewById(R.id.minTimeText);

        TextView teamNameText = (TextView)v.findViewById(R.id.teamNameText);
        TextView areaText = (TextView)v.findViewById(R.id.areaText);


        yearDateText.setText(matchList.get(position).getYearDATE());
        monthDateText.setText(matchList.get(position).getMonthDATE());
        dayDateText.setText(matchList.get(position).getDayDATE());

        sunTimeText.setText(matchList.get(position).getSunTIME());
        hourTimeText.setText(matchList.get(position).getHourTIME());
        minTimeText.setText(matchList.get(position).getMinTIME());

        teamNameText.setText(matchList.get(position).getTeamName());
        areaText.setText(matchList.get(position).getArea());

      //  v.setTag(matchList.get(position).getYearDATE());

        return v;

    }

}
