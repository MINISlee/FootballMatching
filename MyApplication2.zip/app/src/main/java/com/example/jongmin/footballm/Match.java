package com.example.jongmin.footballm;

/**
 * Created by Jongmin on 2017-07-07.
 */

public class Match {
    String kakaoID;
    String teamName;
    String area;
    String phone;
    String yearDATE, monthDATE, dayDATE;
    String sunTIME;
    String hourTIME, minTIME, price;
    String simpleMSG;

    public Match(String teamName, String area, String yearDATE, String monthDATE, String dayDATE, String sunTIME, String hourTIME, String minTIME) {

        this.teamName = teamName;
        this.area = area;

        this.yearDATE = yearDATE;
        this.monthDATE = monthDATE;
        this.dayDATE = dayDATE;
        this.sunTIME = sunTIME;
        this.hourTIME = hourTIME;
        this.minTIME = minTIME;


    }

    public String getKakaoID() {
        return kakaoID;
    }

    public void setKakaoID(String kakaoID) {
        this.kakaoID = kakaoID;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getYearDATE() {
        return yearDATE;
    }

    public void setYearDATE(String yearDATE) {
        this.yearDATE = yearDATE;
    }

    public String getMonthDATE() {
        return monthDATE;
    }

    public void setMonthDATE(String monthDATE) {
        this.monthDATE = monthDATE;
    }

    public String getDayDATE() {
        return dayDATE;
    }

    public void setDayDATE(String dayDATE) {
        this.dayDATE = dayDATE;
    }

    public String getSunTIME() {
        return sunTIME;
    }

    public void setSunTIME(String sunTIME) {
        this.sunTIME = sunTIME;
    }

    public String getHourTIME() {
        return hourTIME;
    }

    public void setHourTIME(String hourTIME) {
        this.hourTIME = hourTIME;
    }

    public String getMinTIME() {
        return minTIME;
    }

    public void setMinTIME(String minTIME) {
        this.minTIME = minTIME;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSimpleMSG() {
        return simpleMSG;
    }

    public void setSimpleMSG(String simpleMSG) {
        this.simpleMSG = simpleMSG;
    }
}
