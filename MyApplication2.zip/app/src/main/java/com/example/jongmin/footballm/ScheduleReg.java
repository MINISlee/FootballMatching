package com.example.jongmin.footballm;

import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import static com.example.jongmin.footballm.R.id.areaSpinner;

public class ScheduleReg extends AppCompatActivity {
    String teamName, phone, kakaoID, price, msg;
    private AlertDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_reg);

        final EditText teamNameText = (EditText)findViewById(R.id.teamNameText);
        final EditText phoneText = (EditText)findViewById(R.id.phoneText);
        final EditText kakaoIDText = (EditText)findViewById(R.id.kakaoIDText);
        final EditText priceText = (EditText)findViewById(R.id.priceText);
        final EditText msgText = (EditText)findViewById(R.id.msgText);




        String[] str = getResources().getStringArray(R.array.areaArray);
        String[] yearStr = getResources().getStringArray(R.array.yearArray);
        String[] monthStr = getResources().getStringArray(R.array.monthArray);
        String[] dayStr = getResources().getStringArray(R.array.dayArray);
        String[] sunStr = getResources().getStringArray(R.array.sunArray);
        String[] hourStr = getResources().getStringArray(R.array.hourArray);
        String[] minStr = getResources().getStringArray(R.array.minArray);



        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, str);
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, yearStr);
        final ArrayAdapter<String> monthAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, monthStr);
        ArrayAdapter<String> dayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, dayStr);
        ArrayAdapter<String> sunAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, sunStr);
        ArrayAdapter<String> hourAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, hourStr);
        ArrayAdapter<String> minAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_dropdown_item, minStr);


       final Spinner spi = (Spinner)findViewById(areaSpinner);
        final  Spinner yearSpi = (Spinner)findViewById(R.id.yearSpinner);
        final Spinner monthSpi = (Spinner)findViewById(R.id.monthSpinner);
        final Spinner daySpi = (Spinner)findViewById(R.id.daySpinner);
        final Spinner sunSpi = (Spinner)findViewById(R.id.sunSpinner);
        final Spinner hourSpi = (Spinner)findViewById(R.id.hourSpinner);
        final Spinner minSpi = (Spinner)findViewById(R.id.minSpinner);

        spi.setAdapter(adapter);
        yearSpi.setAdapter(yearAdapter);
        monthSpi.setAdapter(monthAdapter);
        daySpi.setAdapter(dayAdapter);
        sunSpi.setAdapter(sunAdapter);
        hourSpi.setAdapter(hourAdapter);
        minSpi.setAdapter(minAdapter);


        spi.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected
                            (AdapterView<?> parent, View view, int position, long id){
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent){

                    }
                }
        );

        Button registerButton = (Button)findViewById(R.id.registerButton);
        registerButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
               String teamNameR, phoneR, kakaoIDR, areaR, priceR, messageR;
               String yearR, monthR, dayR, hourR, minR;
               String sunR;

               teamNameR = teamNameText.getText().toString();
               areaR = spi.getSelectedItem().toString();
               kakaoIDR = kakaoIDText.getText().toString();
               phoneR = phoneText.getText().toString();
               priceR = priceText.getText().toString();
               messageR = msgText.getText().toString();

               yearR = yearSpi.getSelectedItem().toString();
               monthR = monthSpi.getSelectedItem().toString();
               dayR = daySpi.getSelectedItem().toString();

               sunR = sunSpi.getSelectedItem().toString();
               hourR = hourSpi.getSelectedItem().toString();
               minR = minSpi.getSelectedItem().toString();

               if (teamNameR.equals("") || areaR.equals("") || kakaoIDR.equals("") || phoneR.equals("") || priceR.equals("") || messageR.equals("") || yearR.equals("") || monthR.equals("") || dayR.equals("") || sunR.equals("") || hourR.equals("") || minR.equals("")) {
                   AlertDialog.Builder builder = new AlertDialog.Builder(ScheduleReg.this);
                   dialog = builder.setMessage("빈 칸 없이 입력 해주세요.")
                           .setNegativeButton("확인", null)
                           .create();
                   dialog.show();
                   return;
               }
               Response.Listener<String> responseListener = new Response.Listener<String>() {

                   @Override
                   public void onResponse(String response) {
                       try {
                           JSONObject jsonResponse = new JSONObject(response);
                           boolean success = jsonResponse.getBoolean("success");
                           if (success) {
                               AlertDialog.Builder builder = new AlertDialog.Builder(ScheduleReg.this);
                               dialog = builder.setMessage("회원 등록에 성공했습니다.")
                                       .setPositiveButton("확인", null)
                                       .create();
                               dialog.show();
                               finish();
                           } else {
                               AlertDialog.Builder builder = new AlertDialog.Builder(ScheduleReg.this);
                               dialog = builder.setMessage("회원 등록에 실패했습니다.")
                                       .setNegativeButton("확인", null)
                                       .create();
                               dialog.show();
                           }
                       } catch (Exception e) {
                           e.printStackTrace();
                       }
                   }
               };
               ScheduleRequest scheduleRequest = new ScheduleRequest(teamNameR, areaR, kakaoIDR, phoneR, yearR, monthR, dayR, sunR, hourR, minR, priceR,messageR, responseListener );
              RequestQueue queue = Volley.newRequestQueue(ScheduleReg.this);
               queue.add(scheduleRequest);
           }
        });
    }

    @Override
    protected void onStop(){
        super.onStop();
        if(dialog != null)
        {
            dialog.dismiss();
            dialog = null;
        }
    }


}
