package com.example.jongmin.footballm;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jongmin on 2017-07-10.
 */

public class ScheduleRequest extends StringRequest {
    final static private String URL ="http://jjong921217.cafe24.com/MatchRegister.php";
    private Map<String, String> parameters;

    public ScheduleRequest(String teamName, String area, String kakaoID, String phone, String yearDATE, String monthDATE, String dayDATE, String sunTIME, String hourTIME, String minTIME, String price, String simpleMSG, Response.Listener<String> listener){
        super(Method.POST,URL,listener,null);
        parameters = new HashMap<>();
        parameters.put("kakaoID", kakaoID);
        parameters.put("teamName", teamName);
        parameters.put("area",area);

        parameters.put("phone", phone);
        parameters.put("yearDATE", yearDATE);
        parameters.put("monthDATE", monthDATE);
        parameters.put("dayDATE", dayDATE);

        parameters.put("sunTIME", sunTIME);
        parameters.put("hourTIME", hourTIME);
        parameters.put("minTIME", minTIME);

        parameters.put("price", price);
        parameters.put("simpleMSG", simpleMSG);

    }
    @Override
    public Map<String,String> getParams(){return parameters;}
}
